package com.ganesh.aisoilhealthassessment.repository;

import com.ganesh.aisoilhealthassessment.model.User;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepositoryImplementation<User, Long> {

    void removeUsersById(long id);
}
